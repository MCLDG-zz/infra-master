'use strict';

var AWS = require('aws-sdk');

console.log('Loading function');

exports.handler = (event, context, callback) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));
    const message = event.Records[0].Sns.Message;
    console.log('From SNS:', message);
    var cloudformation = new AWS.CloudFormation();

    //Inspect the Git event to see if InfraConfig.json was committed
    var commitsadded = message.commits[0].added;
    var commitsmodified = message.commits[0].modified;

    console.log('Commits added:', commitsadded);
    console.log('Commits modified:', commitsmodified);

    var infraconfigupdated = false;
    for (var i = 0; i < commitsadded.length; i++) {
        if (commitsadded[i].indexOf("InfraConfig.json") > -1) {
            infraconfigupdated = true;
        }
    }
    for (var i = 0; i < commitsmodified.length; i++) {
        if (commitsmodified[i].indexOf("InfraConfig.json") > -1) {
            infraconfigupdated = true;
        }
    }
    console.log('infraconfigupdated: ', infraconfigupdated);

    //If InfraConfig.json was committed, retrieve its contents from Git
    if (infraconfigupdated) {
        var fs = require('fs');
        var https = require('https');

        var options = {
            host: "github.com",
            port: 443,
            path: "/MCLDG/infra-project-repo/infra-config/InfraConfig.json",
            method: 'GET',
            rejectUnauthorized: false,
            requestCert: true,
            agent: false
        };

        var request = https.get(options, function(response) {
        	console.log('response is: ', response);
	        var contents = "";
			
			response.on('data', (d) => {
  				contents += d;
  			});
  			response.on('end', () => {
	    		try {
    	  			let parsedData = JSON.parse(contents);
      				console.log(parsedData);
    			} catch (e) {
      				console.log(e.message);
    			}  
    		});
        });

        request.end();

        request.on('error', function(err) {
            throw (err);
        });
    }
    //Retrieve the Infra parameters file from Git

    //Get the location of the CloudFormation template in S3, and trigger CF
    var params = {
        StackName: 'infra-stack',
        Capabilities: ['CAPABILITY_IAM'],
        OnFailure: 'ROLLBACK',
        Parameters: [{
                "ParameterKey": "BastionInstanceType",
                "ParameterValue": "t2.small",
                "UsePreviousValue": false
            },
            {
                "ParameterKey": "BastionKeyName",
                "ParameterValue": "bastion-keypair",
                "UsePreviousValue": false
            },
            {
                "ParameterKey": "KeyName",
                "ParameterValue": "instance-keypair",
                "UsePreviousValue": false
            },
            {
                "ParameterKey": "NATInstanceType",
                "ParameterValue": "t2.small",
                "UsePreviousValue": false
            },
            {
                "ParameterKey": "SSHLocation",
                "ParameterValue": "0.0.0.0/0",
                "UsePreviousValue": false
            }
        ],
        RoleARN: "arn:aws:iam::295744685835:role/infra-role",
        TemplateURL: 'https://s3-ap-southeast-1.amazonaws.com/infra-master/InfraCFTemplate.json',
        TimeoutInMinutes: 60
    };
    //cloudformation.createStack(params, function(err, data) {
    //  if (err) console.log(err, err.stack); // an error occurred
    //  else     console.log(data);           // successful response
    //});

    callback(null, message);
};